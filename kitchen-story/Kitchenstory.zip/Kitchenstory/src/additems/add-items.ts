
export class Item
{
constructor(
    public vegetableid="",
    public vegetablename="",
    public vegetablecost="",
    public vegetableimg="",
    public vegetablequantity="",
    public totalprice=""

){}
}